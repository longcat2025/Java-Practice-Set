import java.util.Random;

public class character {
    private String name;
    private int health;


    public character() {
    }

    public character(String name, int health) {
        this.name = name;
        this.health = health;
    }

    /**
     * 获取
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取
     * @return health
     */
    public int getHealth() {
        return health;
    }

    /**
     * 设置
     * @param health
     */
    public void setHealth(int health) {
        this.health = health;
    }
    public void attack(character role){
        Random ra = new Random();
        int hurt = ra.nextInt(21);
        int remainHealth = role.getHealth() - hurt;
        if(remainHealth <= 0){
            remainHealth = 0;
        }
        System.out.println(this.getName() + "攻击了" + role.getName() + "造成了" + hurt + "的伤害");
        System.out.println(role.getName() + "还剩余血量为" + remainHealth);
        role.setHealth(remainHealth);
    }
}
