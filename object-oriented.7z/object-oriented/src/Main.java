import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        attack();
    }
    public static void attack(){
        character steve = new character("steve",20);
        character alex = new character("alex",20);
        Scanner sc1 = new Scanner(System.in);
        while(true) {
            steve.attack(alex);
            if (alex.getHealth() == 0) {
                System.out.println("alex被击败");
                break;
            }
            alex.attack(steve);
            if (steve.getHealth() == 0) {
                System.out.println("steve被击败");
                break;
            }

        }
    }
}